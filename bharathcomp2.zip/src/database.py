from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import urllib.parse

password = 'postgres'

encoded_password = urllib.parse.quote_plus(password)

SQLALCHEMY_DATABASE_URL = f"postgresql://postgres:{encoded_password}@192.168.0.117:5432/check25"
# SQLALCHEMY_DATABASE_URL = f"postgresql://postgres:{encoded_password}@192.168.0.117:5432/sept25jaa"

engine = create_engine(SQLALCHEMY_DATABASE_URL)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


# from sqlalchemy import create_engine
# from sqlalchemy.ext.declarative import declarative_base
# from sqlalchemy.orm import sessionmaker
# import urllib.parse

# password = 'a'

# encoded_password = urllib.parse.quote_plus(password)

# SQLALCHEMY_DATABASE_URL = f"postgresql://postgres:{encoded_password}@192.168.0.111:9001/jaainprogress"

# engine = create_engine(SQLALCHEMY_DATABASE_URL)

# SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base = declarative_base()